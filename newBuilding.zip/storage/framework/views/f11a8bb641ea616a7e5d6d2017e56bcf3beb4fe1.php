<!doctype html>
<html class="no-js" lang="">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(url('website')); ?>/css/bootstrap.css">
	<link rel="stylesheet" href="<?php echo e(url('website')); ?>/css/fancybox.css">
	<link rel="stylesheet" href="<?php echo e(url('website')); ?>/style.css">
    <link href="<?php echo e(url('css/alertify.min.css')); ?>" id="theme" rel="stylesheet">

    <?php echo $__env->yieldContent('header'); ?>
</head>
<body>

    

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('website/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



	<script src="<?php echo e(url('website')); ?>/js/jquery.js"></script>
	<script src="<?php echo e(url('website')); ?>/js/plugins.js"></script>
	<script src="<?php echo e(url('website')); ?>/js/bootstrap-slider.min.js"></script>
	<script src="<?php echo e(url('website')); ?>/js/jquery.main.js"></script>
	<script type="text/javascript" src="<?php echo e(url('website')); ?>/js/init.js"></script>
    <script src="<?php echo e(url('js/alertify.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/select2.min.js')); ?>"></script>

    <script>
        $(document).ready(function () {

            <?php if(Session::has('success')): ?>
                alertify.alert('Congratulation', "<?php echo e(session()->get('success')); ?>").delay(3);

            <?php elseif(Session::has('error')): ?>
                alertify.set('notifier','position', 'top-center');
                alertify.success("<?php echo e(session()->get('error')); ?>");

            <?php endif; ?>
        });
    </script>

    <?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
