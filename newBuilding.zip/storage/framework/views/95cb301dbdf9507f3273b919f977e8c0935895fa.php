<?php $__env->startSection('title'); ?>
    Edit Post: <?php $__currentLoopData = $edit_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(str_limit($post->title)); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        .strong{
            position: relative;
            top: -12px;
            color: #e05454;
            font-size: 12px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row bg-title">
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <h4 class="page-title">Edit post: <?php $__currentLoopData = $edit_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span style="color: royalblue;text-decoration: underline;"><?php echo e(str_limit($post->title , 50)); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h4> </div>
                <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('admin-panel')); ?>">Dashboard</a></li>
                        <li class="active">Edit post: <?php $__currentLoopData = $edit_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(str_limit($post->title , 30)); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                    </ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-info">
                        <div class="panel-wrapper collapse in" aria-expanded="true">
                            <div class="panel-body">
                                <?php $__currentLoopData = $edit_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(url('admin-panel/posts/edit/'.$post->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label"> Title</label>
                                                    <input type="text" id="title" class="form-control" name="title" placeholder="Title..." value="<?php echo e($post->title); ?>">
                                                </div>

                                                <?php if($errors->has('title')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong class="strong"><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label"> Category</label>
                                                    <select class="form-control" name="category">
                                                        <option value="<?php echo e($post->category); ?>"><?php echo e($post->category); ?></option>
                                                        <option value="Marketing">Digital Marketing</option>
                                                        <option value="Design">Creative Design</option>
                                                        <option value="Photography">Photography</option>
                                                        <option value="Campaign">Social Campaign</option>
                                                        <option value="Printing">Printing</option>
                                                    </select>
                                                    <?php if($errors->has('category')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong class="strong"><?php echo e($errors->first('category')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label"> Status</label>
                                                    <select class="form-control" name="status" >
                                                        <option value="<?php echo e($post->status); ?>"><?php echo e($post->status); ?></option>
                                                        <option value="Activate">Activate</option>
                                                        <option value="Not Activate">Not Activate</option>
                                                    </select>
                                                    <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong class="strong"><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">post Photo</label>
                                                    <input type="hidden" name="image_hidden" value="<?php echo e($post->image); ?>">
                                                    <input type="file" name="image" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label"> Description</label>
                                                    <textarea id="body" class="form-control" name="body" placeholder="Description..." rows="5"><?php echo e($post->body); ?></textarea>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <img src="<?php echo e(url('admin/images/posts/'.$post->image)); ?>" class="img-responsive" style="width:200px; height: 150px;border-radius: 5px;"/>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="form-actions m-t-40">
                                        <button type="submit" class="btn btn-success"> <i class="fa fa-check"></i> Save</button>
                                    </div>
                                </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>